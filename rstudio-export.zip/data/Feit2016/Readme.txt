The HOW-WE-TYPE dataset
===================================
http://userinterfaces.aalto.fi/how-we-type

This is the HOW-WE-Type dataset. 
It contains keystroke data of 30 participants typing regular sentences, automatically annotated with information about which finger presses which key, based on motion capture recordings.

NOTE: this version of the dataset only contains data of the condition "sentences". It only contains annotated keystroke data. Please contact Anna Feit if you are interested in the accompanying motion capture data or eye tracking data. 

More details about the study and its procedure can be found in the paper:

Anna Maria Feit, Daryl Weir, Antti Oulasvirta 
How We Type: Movement Strategies and Performance in Everyday Typing 
In Proceedings of the SIGCHI Conference on Human Factors in Computing Systems, ACM, 2016

If you have questions, please contact Anna Feit:
anna.feit@aalto.fi

----------------------------------
LICENSE AND ATTRIBUTION
----------------------------------

You are free to use this data for non-commercial use in your own research or projects with attribution to the authors. 

Please cite: 

Anna Maria Feit, Daryl Weir, Antti Oulasvirta 
How We Type: Movement Strategies and Performance in Everyday Typing 
In Proceedings of the SIGCHI Conference on Human Factors in Computing Systems, ACM, 2016

@inproceedings{Feit2016_how_we_type,
 author = {Feit, Anna Maria and Weir, Daryl and Oulasvirta, Antti},
 title = {How We Type: Movement Strategies and Performance in Everyday Typing},
 booktitle = {Proceedings of the 34th Annual ACM Conference on Human Factors in Computing Systems},
 series = {CHI '16},
 year = {2016},
 pages = {4262-4273},
 url = {http://dx.doi.org/10.1145/2858036.2858233},
 doi = {10.1145/2858036.2858233},
 acmid = {2858233},
 publisher = {ACM},
 address = {New York, NY, USA},
 keywords = {text entry; typing performance; touch typing; movement strategies; motion capture data},
}

----------------------------------
CONTENT
----------------------------------
  
- Typing data:
  recorded keypresses at a sample rate of 40 ms,
  contains the log data extended with the executing finger. 
  explanation of data columns: see below

- Background.xlsx
  Subjective responses to the survey, filled by the participants after the study.
  
----------------------------------
EXPLANATION OF DATA COLUMNS
----------------------------------

Typing data: 
Note: The first column is a continous row counter
	
	input_time: long
	the timestamp of the keypress
	
	user_id: int, 6-digit number
	The user id of the participant (stays the same throughout the file)
	
	stimulus_id: int
	the number of the current stimulus. 
	This changes as soon as the enter key was hit (stays the same until the next stimulus is shown)
	
	input_index: int
	the index of the typed letter within the typed response. 
	
	iki: int
	the inter-key interval, that is the time between the last and the current keypress. 

	input: string
	the typed letter, as appearing on the screen. 

	key_symbol: string	
	the name of the typed key. 
	
	current_input: string
	The typed response. 
	This changes as soon as the enter key was hit (stays the same until the next stimulus is shown)
	
	finger: {L_Thumb, L_Index, L_Middle, ...}
	The finger used for the keypress ("[L,R]_[Thumb, Index, Middle, Ring, Little]")
	
	right_hand: binary {0,1}
	1, if the right hand was used to press the key. 
	
	stimulus: string
	the current stimulus. 
	This changes as soon as the enter key was hit (stays the same until the next stimulus is shown)
	
	bigram: string
	The letter pair (bigram) consisting of the previous and current keystroke
	The first letter in the bigram is * if this was the first keypress in this stimulus

	last_input: 
	The key_symbol of the key that was typed before that keypress. 
	* if this was the first keypress in this stimulus

	last_finger: {L_Thumb, L_Index, L_Middle, ...}
	The finger that performed the previous keystroke ("[L,R]_[Thumb, Index, Middle, Ring, Little]")	
===============================================	